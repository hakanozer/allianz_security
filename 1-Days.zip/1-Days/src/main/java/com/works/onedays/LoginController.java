package com.works.onedays;

import java.util.Optional;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@Controller
public class LoginController {
	
	@GetMapping(value = { "/login", "/login/{data}" })
	public String login( @PathVariable(value = "") Optional<String> data, Model model ) {
		System.out.println("data : " + data);
		if (data.isPresent()) {
			if (data.get().contains("script")) {
				// kullanıcı saldırı halinde
				model.addAttribute("error", "XSS saldırısı yapıyorsunuz");
			}else {
				model.addAttribute("datax", data.get());
			}
		}
		return "login";
	}

}
