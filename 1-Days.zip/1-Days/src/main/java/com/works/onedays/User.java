package com.works.onedays;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.Length;

public class User {

	//@NotNull(message = "Lütfen adınızı giriniz!")
	@NotEmpty(message = "Lütfen adınızı giriniz!")
	private String name;
	
	@NotEmpty(message = "Lütfen soyadınızı giriniz!")
	private String surname;
	
	@NotEmpty(message = "Lütfen mail giriniz!")
	@Email(message = "Lütfen geçerli bir mail giriniz")
	private String mail;
	
	@Length(min=3, max = 10, message = "En az 3 en faz 10 giriniz")
	private String pass;
	
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSurname() {
		return surname;
	}
	public void setSurname(String surname) {
		this.surname = surname;
	}
	public String getMail() {
		return mail;
	}
	public void setMail(String mail) {
		this.mail = mail;
	}
	public String getPass() {
		return pass;
	}
	public void setPass(String pass) {
		this.pass = pass;
	}
	
	
	
}
