package com.works.onedays;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class DashboardController {
	
	@GetMapping("/dashboard")
	public String dashboard( HttpSession session, Model model ) {

		
		boolean statu = session.getAttribute("user") == null;
		if(statu) {
			return "redirect:/login";
		}
		User us = (User) session.getAttribute("user");
		model.addAttribute("user", us);
		return "dashboard";
	}

}
