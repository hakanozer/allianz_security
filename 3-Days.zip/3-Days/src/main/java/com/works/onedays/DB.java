package com.works.onedays;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

public class DB {
	 
    private final String url = "jdbc:mysql://localhost/ornekvt?useUnicode=true&characterEncoding=utf-8";
    private final String uName = "root";
    private final String uPass = "";
    private final String driver = "com.mysql.jdbc.Driver";
   
    private Connection conn = null;
    private Statement st = null;
    private PreparedStatement pre = null;
   
    public DB() {
        try {
            Class.forName(driver);
            conn = DriverManager.getConnection(url, uName, uPass);
            System.out.println("Connected");
        } catch (Exception e) {
            System.err.println("Connect Error : " + e);
        }
    }
   
   // ' or '1'='1
    boolean loginSta(User us) {
        try {
           
            st = conn.createStatement();
            String query = "select *from user where mail = '"+us.getMail()+"' and pass = '"+us.getPass()+"'";
            System.out.println("query : " + query);
            ResultSet rs = st.executeQuery(query);
            if (rs.next()) {
                System.out.println("Giriş Başarılı");
                return true;
            }else {
                System.out.println("Giriş Hatalı");
                return false;
            }
           
        } catch (Exception e) {
            System.err.println("loginPre : " + e);
            return false;
        }
    }
   
   
    boolean loginPre(User us) {
        try {
            String query = " select * from user where mail = ? and pass = ? ";
            pre = conn.prepareStatement(query);
            pre.setString(1, us.getMail());
            pre.setString(2, us.getPass());
            ResultSet rs = pre.executeQuery();
            if (rs.next()) {
                System.out.println("Giriş Başarılı");
                return true;
            }else {
                System.out.println("Giriş Hatalı");
                return false;
            }
        } catch (Exception e) {
            System.err.println("loginPre : " + e);
            return false;
        }
    }
    
}