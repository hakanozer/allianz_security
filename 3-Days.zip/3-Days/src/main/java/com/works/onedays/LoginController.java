package com.works.onedays;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class LoginController {
	
	DB db = new DB ();
	
	@GetMapping(value = "/login" )
	public String login( HttpSession session ) {
		// session id
		String sessionID = session.getId();
		// daha önceden kayıt varsa
		session.invalidate(); // bu tarayıcı için tüm oturumları kapat.
		System.out.println("Session id : " + sessionID);
		
		return "login";
	}
	
	
	@PostMapping("/userLogin")
	public String userLogin( User us, HttpSession session ) {
		boolean statu = db.loginSta(us);
		if(statu) {
			// giriş başarılı
			session.setAttribute("user", us);
			return "redirect:/dashboard";
		}
		return "login";
	}
	

}
