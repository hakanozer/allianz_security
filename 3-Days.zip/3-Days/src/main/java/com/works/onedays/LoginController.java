package com.works.onedays;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.boot.web.servlet.server.Session;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class LoginController {
	
	DB db = new DB ();
	
	@GetMapping(value = "/login" )
	public String login( HttpSession session, HttpServletRequest req ) {
		
		// session id
		String sessionID = session.getId();
		// daha önceden kayıt varsa
		//session.invalidate(); // bu tarayıcı için tüm oturumları kapat.
		session.removeAttribute("user");
		
		
		// cookie value
		if(req.getCookies() != null ) {
			Cookie[] arr = req.getCookies();
			for (Cookie item : arr) {
				if(item.getName().equals("userCookie")) {
					String val = item.getValue();
					System.out.println("Val : " + val);
					String valEncode = Util.sifreCoz(val, 3);
					System.out.println("valEncode : " + valEncode);
					
					User us = new User();
					us.setMail(valEncode);
					session.setAttribute("user", us);
				}
			}
		}

		System.out.println("Session id : " + sessionID);
		return "login";
	}
	
	
	@PostMapping("/userLogin")
	public String userLogin( User us, HttpSession session, HttpServletResponse res  ) {
		boolean statu = db.loginPre(us);
		if(statu) {
			// giriş başarılı
			session.setAttribute("user", us);
			
			// remember me
			System.out.println("Remember : " + us.getRemember_me());
			if(us.getRemember_me().equals("on")) {
				// Cookie Create
				Cookie cookie = new Cookie("userCookie", Util.sifrele(us.getMail(), 3));
				cookie.setMaxAge(60*60*24);
				res.addCookie(cookie);
			}
			
			return "redirect:/dashboard";
		}
		return "login";
	}
	

}
