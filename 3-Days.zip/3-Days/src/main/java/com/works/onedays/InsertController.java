package com.works.onedays;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class InsertController {
	
	@GetMapping("/insertUser")
	public String insert() {
		return "insertUser";
	}

	@PostMapping("/insertUser")
	public String insertUser( User us) {
		System.out.println("User : " + us.getName());
		return "insertUser";
	}
	
	
}
