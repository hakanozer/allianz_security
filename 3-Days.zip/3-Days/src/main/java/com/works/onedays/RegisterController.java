package com.works.onedays;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class RegisterController {

	
	@GetMapping("/register")
	public String register(Model model) {
		model.addAttribute("validUser", new User());
		return "register";
	}
	
	
	@PostMapping("/userRegister")
	public String userRegister( @Valid @ModelAttribute("validUser") User us, BindingResult bind ) {
		if(bind.hasErrors()) {
			// hata var
			System.out.println("Hata var");
		}else {
			// hata yok
			System.out.println("Hata yok, Gönderilebilir.");
		}
		System.out.println("name : " + us.getName());
		return "register";
	}

	
	
}
